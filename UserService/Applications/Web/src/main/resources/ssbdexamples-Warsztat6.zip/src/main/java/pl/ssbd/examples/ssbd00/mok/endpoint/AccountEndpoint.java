package pl.ssbd.examples.ssbd00.mok.endpoint;


import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Inject;
import jakarta.validation.Valid;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import pl.ssbd.examples.ssbd00.dto.*;
import pl.ssbd.examples.ssbd00.model.*;
import pl.ssbd.examples.ssbd00.mok.manager.AccountManagerLocal;
import pl.ssbd.examples.ssbd00.util.converters.*;
import pl.ssbd.examples.ssbd00.exceptions.*;

import java.util.List;
import java.util.UUID;
import java.util.logging.Logger;

@Path("accounts")
@RequestScoped
public class AccountEndpoint {

    @Inject
    private AccountManagerLocal accountManager;

    private static final Logger LOG = Logger.getLogger(AccountEndpoint.class.getName());

    // Brakuje segmentów obsługi wyjątków?
    // @see pl.ssbd.examples.ssbd00.exceptions.mappers.WebEndpointExceptionMapper

    // BARDZO trudna, a zwłaszcza do zaimplementowania w czysty sposób, jest realizacja metody REST o zmiennej liczbie parametrów o różnych klasach potomnych
    // Dlatego w modelu przyjęto, że zawsze tworzone będzie konto z jednym z dostępnych poziomów dostępu,
    // a ewentualne inne poziomy dostępu będą dodawane później
    @POST
    @Path("/clients")
    @Consumes({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    public Response createClientAccount(@Valid CreateClientDTO createClientDTO) {
        Account newAccount = accountManager.createNewClient(
                AccountConverter.createNewAccountEntity(createClientDTO.getAccount(), createClientDTO.getPassword()),
                AccesslevelConverter.createNewClientEntity(createClientDTO.getClient()));
        return Response.status(Response.Status.CREATED)
                .entity(AccountConverter.createAccountWithAccessLevelsDTO(newAccount))
                .build();

    }


    @GET
    @Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    public List<AccountDTO> findAllAccounts() {
        return AccountConverter.createAccountDTOList(accountManager.findAllAccounts());
    }

    @GET
    @Path("/clients")
    @Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    public List<AccountDTO> findAllClientAccounts() {
        return AccountConverter.createAccountDTOList(accountManager.findAllClientAccounts());
    }

    // http http://localhost:8080/api/konto/1
    @GET
    @Path("{id}")
    @Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    public AccountDTO findAccount(@PathParam("id") UUID id) {
        return AccountConverter.createAccountDTO(accountManager.findAccount(id));
    }

    @GET
    @Path("{id}/details")
    @Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    public AccountWithAccessLevelsDTO findAccountWithAccessLevels(@PathParam("id") UUID id) {
        return AccountConverter.createAccountWithAccessLevelsDTO(accountManager.findAccountWithAccessLevels(id));
    }

    @POST
    @Path("{id}/verify")
    @Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    public AccountDTO verifyAccount(@PathParam("id") UUID id) {
                return AccountConverter.createAccountDTO(
                        accountManager.markAccountVerified(id)
                );
    }


    /*
    PATCH + merge-patch+json to fajna sprawa, ale wyklucza zastosowanie @NotNull wobec pól.
    Alternatywą jest używanie PUT i osobnego (zredukowanego do pól modyfikowalnych) DTO.
     */
    /*
    Dość dziwne może być przekazywanie nowych danych do managera jako sztucznie wytworzona "encja".
    Motywacją jet niechęć do wiązania managera z DTO i kowerterami.
    Alternatywa - przekazywanie jako seria atrybutów (String, String, String) - też mało atrakcyjna.
     */
    @PATCH
    @Path("{id}")
    @Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    @Consumes("application/merge-patch+json")
    public Response updateAccount(@PathParam("id") UUID id, @Valid AccountDTO accountUpdateData) {
        return Response.status(Response.Status.OK).entity(
                AccountConverter.createAccountDTO(
                        accountManager.updateAccount(id, accountUpdateData.getVersion(), AccountConverter.createNewAccountEntity(accountUpdateData, ""))
                )
        ).build();
    }


    @DELETE
    @Path("{id}")
    public void removeAccount(@PathParam("id") UUID id) {
        accountManager.removeAccount(id);
    }

}
