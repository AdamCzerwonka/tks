GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.account TO ssbd00mok;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.personal_data TO ssbd00mok;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.access_level TO ssbd00mok;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.admin_data TO ssbd00mok;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.client_data TO ssbd00mok;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.manager_data TO ssbd00mok;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.account_noi TO ssbd00mok;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.personal_data_noi TO ssbd00mok;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.access_level_noi TO ssbd00mok;

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.invoice TO ssbd00moi;
GRANT SELECT ON TABLE public.account TO ssbd00moi;
GRANT SELECT ON TABLE public.personal_data TO ssbd00moi;
GRANT SELECT ON TABLE public.access_level TO ssbd00moi;
GRANT SELECT ON TABLE public.admin_data TO ssbd00moi;
GRANT SELECT ON TABLE public.client_data TO ssbd00moi;
GRANT SELECT ON TABLE public.manager_data TO ssbd00moi;

GRANT SELECT ON TABLE public.account TO ssbd00auth;
GRANT SELECT ON TABLE public.personal_data TO ssbd00auth;
GRANT SELECT ON TABLE public.access_level TO ssbd00auth;
GRANT SELECT ON TABLE public.admin_data TO ssbd00auth;
GRANT SELECT ON TABLE public.client_data TO ssbd00auth;
GRANT SELECT ON TABLE public.manager_data TO ssbd00auth;

INSERT INTO public.account (id, version, active, login, password, verified) VALUES ('00000000-0000-0000-0000-000000000011', 0, true, 'client11', 'makeithash', false);
INSERT INTO public.personal_data (id, name, surname, email) VALUES ('00000000-0000-0000-0000-000000000011', 'c11name', 'c11surname', 'client@11.com');
INSERT INTO public.access_level (id, version, level, active, account_id) VALUES ('00000000-0000-0000-0000-000000001101', 0, 'CLIENT', true, '00000000-0000-0000-0000-000000000011');
INSERT INTO public.client_data (id, nip) VALUES ('00000000-0000-0000-0000-000000001101', '0000000011');
INSERT INTO public.invoice (id, version, status, amount, issuedate, client_id) VALUES ('00000000-0000-0000-0000-000000000021', 0, 'ISSUED', 1234.56, '2024-03-22 00:17:33.000000', '00000000-0000-0000-0000-000000001101');

INSERT INTO public.account (id, version, active, login, password, verified) VALUES ('00000000-0000-0000-0000-000000000012', 0, true, 'boss12', 'makeithash', true);
INSERT INTO public.personal_data (id, name, surname, email) VALUES ('00000000-0000-0000-0000-000000000012', 'b12name', 'b12surname', 'boss@this.biz');
INSERT INTO public.access_level (id, version, level, active, account_id) VALUES ('00000000-0000-0000-0000-000000001201', 0, 'ADMIN', true, '00000000-0000-0000-0000-000000000012');
INSERT INTO public.admin_data (id, alarm_code) VALUES ('00000000-0000-0000-0000-000000001201', '000000001201');
INSERT INTO public.access_level (id, version, level, active, account_id) VALUES ('00000000-0000-0000-0000-000000001202', 0, 'MANAGER', true, '00000000-0000-0000-0000-000000000012');
INSERT INTO public.manager_data (id, phone) VALUES ('00000000-0000-0000-0000-000000001202', '000000001202');
