package pl.ssbd.examples.ssbd00.model;

import java.io.Serializable;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity // UniqueConstraint nakłada ograniczenie unikalności na parę konto-poziom dostępu
@Table(name = "access_level", uniqueConstraints = {@UniqueConstraint(columnNames = {"account_id", "level"})})
/* Adnotacja opisująca tę klasę jako nadrzędną w dziedziczeniu klas encyjnych.
 *
 * Dziedziczenie zastępuje związki 1:1 oraz pozwala automatycznie ustawiać poziom dostępu.
 *
 * InheritanceType - strategia rozłożenia danych z klasy nadrzędnej i klas dziedziczących na tabele w bazie danych.
 * JOINED: klasa nadrzedna oraz klasy dziedziczące mają własne dedykowane tabele.
 * Związek pomiędzy krotkami poszczególnych tabel wyznacza relacja równości kluczy głównych.
 * Strategia jako jedyna zapewnia zgodność z 3 NF schematu bazy.
 *
 */
@Inheritance(strategy = InheritanceType.JOINED)
/* Adnotacja wskazuje kolumnę w tabeli reprezentującej klasę AccessLevel, której wartości będą wyróżniały poszczególne klasy dziedziczące.
 * W przypadku klasy AccessLevel wartość w tej kolumnie jednocześnie określa poziom dostępu.
 * Poszczególne wartości są nadawane automatycznie zgodnie z adnotacjami @DiscriminatorValue klas dziedziczących.
 */
@DiscriminatorColumn(discriminatorType = DiscriminatorType.STRING, name = "level")
@NamedQueries({
        //UWAGA! Kwerenda znajduje obiekty traktując jako kryterium własciwość obiektu powiązanego
        @NamedQuery(name = "AccessLevel.findByLogin", query = "SELECT al FROM AccessLevel al WHERE al.account.login = :login")
})

@ToString(callSuper = true)
// Powodem dla którego ta klasa jest oznaczona jako abstrakcyjna jest to, że w przyjętym modelu 
// istnienie instancji bazowej AccessLevel nie ma znaczenia. W innych modelach może być przyjęta inna konwencja.
public abstract class AccessLevel extends AbstractEntity implements Serializable {
//    Wersja i klucz główny są dziedziczone z klasy bazowej
//    Gettery, settery i toString generowane przez Lombok

    private static final long serialVersionUID = 1L;

    /* Wartość w kolumnie poziom jest generowana automatycznie poprzez zastosowanie mechanizmu
    dziedziczenia ze strategia Joined, ustawieniu kolumny jako DiscriminatorColumn oraz
    ustawianiu DiscriminatorValue dla klas dziedziczących.
    Poniższe mapowanie tej kolumny nie jest obowiązkowe, ale może być przydatne do odczytu informacji
    o poziomach dostępu użytkownika przy implementacji uwierzytelniania.
    Jakkolwiek od Java 21 mamy pattern matching switch, którym można stosunkowo łatwo zastąpić to mapowanie. Kwestia wyboru.
    Na pewno jednak nie ma sensu ustawianie tej wartości przez aplikację. Stąd brak konstruktora inicjującego i settera.
     */
    //@NotNull
//    @Size(min = 1, max = 16)
    @Column(name = "level", updatable = false, length = 16, nullable = false)
    @Getter
    private String level;

    /* Rozwiązanie opcjonalne umożliwia odebranie poziomu dostępu bez usuwania krotki.
     */
    //@NotNull
    @Getter
    @Setter
    @Column(name = "active", nullable = false)
    private boolean active = true;

    /* Adnotacje opisujące związek 1:M po stronie wielokrotnej, będącej też właścicielem związku.
     * @JoinColumn - wskazuje kolumnę (konto_id) stanowiącą klucz obcy do tabeli konto (to wiadomo dzięki klasie pola), a dokładnie
     * do kolumny id (klucza głównego) tej tabeli.
     * @ManyToOne - wskazuje liczność związku.
     *      optional=false - związek musi być zawsze spięty (kompozycja)
     *      cascade - deklaracja operacji, które mają być kaskadowo wykonywane przez zarządcę encji na zagnieżdżonych obiektach encji.
     *          Uzyta w przykładzie kaskada PERSIST pozwala na utworzenie jednocześnie poziomu dostępu i konta (przez utrwalenie encji PoziomDostepu)
     *          Operacje kaskadowe zarządcy encji zastępują i wykluczają się z kaskadami na poziomie bazy danych.
     */
    @JoinColumn(name = "account_id", referencedColumnName = "id", updatable = false)
    @ManyToOne(optional = false, cascade = CascadeType.PERSIST)
    @Getter @Setter
    private Account account;

    protected AccessLevel() {
    }

}
