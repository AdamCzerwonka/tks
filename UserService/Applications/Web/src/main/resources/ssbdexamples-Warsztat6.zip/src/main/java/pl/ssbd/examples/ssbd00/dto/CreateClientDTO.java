package pl.ssbd.examples.ssbd00.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@ToString
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CreateClientDTO {
    private AccountDTO account;
    private ClientDTO client;
    @ToString.Exclude
    private String password;
}
