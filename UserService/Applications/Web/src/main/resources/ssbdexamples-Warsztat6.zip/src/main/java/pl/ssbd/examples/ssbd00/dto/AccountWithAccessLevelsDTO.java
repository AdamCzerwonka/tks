package pl.ssbd.examples.ssbd00.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;
import java.util.UUID;

// Alternatywna wersja AccountDTO zawierająca poziomy dostępu
// Może być przydatna np. do wyświetlenia szczegółowego widoku konta
// Zawsze 2x się zastanów czy na pewno potrzebujesz przenosić kolekcje do DTO
// Przeważnie lepszym rozwiązaniem jest udostępnienie w API metody do pobrania tej kolekcji wtedy, kiedy jest to NAPRAWDĘ potrzebne
// Klasa NIGDY nie będzie użyta do przesyłania obiektów od warstwy prezentacji do logiki
// Nie będzie też konwertera na encję
@ToString(callSuper = true)
public class AccountWithAccessLevelsDTO extends AccountDTO {

    @Getter
    @Setter
    @ToString.Exclude // Rozpięcie wzajemnego wywoływania toString() między Konto a PoziomDostepu
    private List<AccessLevelDTO> accessLevels;

    public AccountWithAccessLevelsDTO() {
    }

    // Konstruktor do konwersji encja -> DTO obejmujący wszystkie pola
    public AccountWithAccessLevelsDTO(String login, boolean verified, boolean active, List<AccessLevelDTO> accessLevels, String name, String surname, String email, UUID id, long version) {
        super(login,verified,active,name,surname,email,id,version);
        this.accessLevels = accessLevels;
    }

}
