package pl.ssbd.examples.ssbd00.tx;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.Resource;
import jakarta.transaction.TransactionScoped;
import jakarta.transaction.TransactionSynchronizationRegistry;

import java.io.Serializable;

@TransactionScoped
public class TransactionKeyTracker implements Serializable {


    @Resource
    private TransactionSynchronizationRegistry txRegistry;

    private String txKey;

    @PostConstruct
    private void init() {
        txKey = txRegistry.getTransactionKey().toString();
        txRegistry.registerInterposedSynchronization(new TransactionSynchronization(txKey));
        System.out.println("TX init: "+ txKey);
    }

    public String getTxKey() {
        return txKey;
    }
}
