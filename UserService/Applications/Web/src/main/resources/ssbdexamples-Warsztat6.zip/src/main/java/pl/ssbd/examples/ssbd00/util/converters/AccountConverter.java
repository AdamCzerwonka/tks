package pl.ssbd.examples.ssbd00.util.converters;

import pl.ssbd.examples.ssbd00.dto.*;
import pl.ssbd.examples.ssbd00.model.*;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public class AccountConverter {
    
    // Ta konwersja jest używana do wysyłania obiektów do warstwy prezentacji
    // W przypadku tego DTO NIE MA konwersji w drugą stronę!!!
    public static AccountWithAccessLevelsDTO createAccountWithAccessLevelsDTO(Account account) {
        return new AccountWithAccessLevelsDTO(account.getLogin(), account.isVerified(), account.isActive(),
                AccesslevelConverter.createAccessLevelDTOList(account.getAccessLevels()),
                account.getName(), account.getSurname(), account.getEmail(),
                account.getId(), account.getVersion());
    }
    
    // Ta konwersja jest używana do wysyłania obiektów do warstwy prezentacji
    public static AccountDTO createAccountDTO(Account account) {
        return new AccountDTO(account.getLogin(), account.isVerified(), account.isActive(),
                account.getName(), account.getSurname(), account.getEmail(),
                account.getId(), account.getVersion());
    }
    
    // Ta konwersja jest używana do utworzenia NOWEGO (i tylko nowego) obiektu encji na podstawie danych z warstwy prezentacji
    public static Account createNewAccountEntity(AccountDTO accountDTO, String password) {
        return new Account(accountDTO.getLogin(), password,
                accountDTO.getName(), accountDTO.getSurname(), accountDTO.getEmail());
    }
    
    // Konwersja listy encji na listę DTO
    public static List<AccountDTO> createAccountDTOList(List<Account> accounts) {
        return null == accounts ? null : accounts.stream()
        .filter(Objects::nonNull)
        .map(elt -> AccountConverter.createAccountDTO(elt))
        .collect(Collectors.toList());    
    }
    
}
