/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pl.ssbd.examples.ssbd00.mok.manager;

import jakarta.ejb.Local;
import pl.ssbd.examples.ssbd00.model.Account;
import pl.ssbd.examples.ssbd00.model.Client;
import pl.ssbd.examples.ssbd00.model.*;

import java.util.List;
import java.util.UUID;

/**
 *
 * @author student
 */
@Local
public interface AccountManagerLocal {

    public Account createNewClient(Account account, Client client);

    public Account createNewAccount(Account account, AccessLevel accessLevel);
    
    public List<Account> findAllAccounts();
    
    public Account findAccount(UUID id);
    
    // Zobacz implementację tej metody żeby sprawdzić czym poniższa metoda różni się od powyższej
    // Hint: Lazy loading!
    public Account findAccountWithAccessLevels(UUID id);

    public Account markAccountVerified(UUID id);

    public Account updateAccount(UUID id, long version, Account accountUpdateData);

    public List<Account> findAllClientAccounts();

    public void removeAccount(UUID id);

    public void aMethodThatIsntControlledByRolesAllowed();
    
}
