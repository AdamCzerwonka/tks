package pl.ssbd.examples.ssbd00.rest;

import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.Response;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import pl.ssbd.examples.ssbd00.dto.AccountDTO;
import pl.ssbd.examples.ssbd00.dto.ClientDTO;
import pl.ssbd.examples.ssbd00.dto.CreateClientDTO;
import pl.ssbd.examples.ssbd00.restclient.AccountRestClient;

import java.util.List;

public class AccountRestTest {

    /* IMPORTANT NOTES:
    1. These tests are expected to be performed AFTER application deployment. They're not unit tests!
        That's why "skip tests" is set in Maven POM / project run configuration.
    2. These tests rely (at least partially) on initial database data loaded from init.sql.
     */
    @Test
    @DisplayName("get all accounts")
    public void getAllClients() {
        Response getAllAccountsResponse = new AccountRestClient().findAll();
        Assertions.assertEquals(getAllAccountsResponse.getStatus(), Response.Status.OK.getStatusCode());
        List<AccountDTO> accountDTOList = getAllAccountsResponse.readEntity(new GenericType<List<AccountDTO>>() {
        });
        Assertions.assertTrue(accountDTOList.size() >= 2);

    }

    @Test
    public void createNewClient() { //This is positive scenario
        CreateClientDTO newClient = new CreateClientDTO(
                // This is not too clean. Maybe we should define CreateClientDTO from scratch
                new AccountDTO("newclient11",false,false,"ncli11name","ncli11surname","ncli11@email.com",null,0), //ONLY login, name, surname, email are used
                new ClientDTO("0010010101",null,null,0), // ONLY NIP is used
                "ncli11pwd"
        );

        Response createNewClientResponse = new AccountRestClient().createClient(newClient);
        Assertions.assertEquals(createNewClientResponse.getStatus(), Response.Status.CREATED.getStatusCode());
        AccountDTO returnedAccountDTO = createNewClientResponse.readEntity(AccountDTO.class);

        //Now let's try to get the new account
        //Does it invoke SQL SELECT query? Check it out!
        Response findAccountResponse = new AccountRestClient().find(returnedAccountDTO.getId());
        Assertions.assertEquals(findAccountResponse.getStatus(), Response.Status.OK.getStatusCode());
        AccountDTO foundAccountDTO = findAccountResponse.readEntity(AccountDTO.class);
        Assertions.assertEquals(foundAccountDTO.getLogin(), "newclient1");
    }

    @Test
    public void verifyAccount() { //This is positive scenario
        CreateClientDTO newClient = new CreateClientDTO(
                // This is not too clean. Maybe we should define CreateClientDTO from scratch
                new AccountDTO("newclient21",false,false,"ncli21name","ncli21surname","ncli21@email.com",null,0), //ONLY login, name, surname, email are used
                new ClientDTO("0010010201",null,null,0), // ONLY NIP is used
                "ncli21pwd"
        );

        Response createNewClientResponse = new AccountRestClient().createClient(newClient);
        Assertions.assertEquals(createNewClientResponse.getStatus(), Response.Status.CREATED.getStatusCode());
        AccountDTO returnedAccountDTO = createNewClientResponse.readEntity(AccountDTO.class);

        //Now let's try to get the new account
        //It is proper account - this is checked by other test
        Response findAccountResponse = new AccountRestClient().find(returnedAccountDTO.getId());
        Assertions.assertEquals(findAccountResponse.getStatus(), Response.Status.OK.getStatusCode());
        AccountDTO foundAccountDTO = findAccountResponse.readEntity(AccountDTO.class);
        Assertions.assertFalse(foundAccountDTO.isVerified()); // it should be false by default

        //Now let's try to verify the new account
        Response verifyAccountResponse = new AccountRestClient().verify(returnedAccountDTO.getId());
        Assertions.assertEquals(verifyAccountResponse.getStatus(), Response.Status.OK.getStatusCode());
        AccountDTO verifiedAccountDTO = verifyAccountResponse.readEntity(AccountDTO.class);
        Assertions.assertTrue(verifiedAccountDTO.isVerified()); // it should be true now

        //But is that change persisted?
        findAccountResponse = new AccountRestClient().find(returnedAccountDTO.getId());
        Assertions.assertEquals(findAccountResponse.getStatus(), Response.Status.OK.getStatusCode());
        foundAccountDTO = findAccountResponse.readEntity(AccountDTO.class);
        Assertions.assertTrue(foundAccountDTO.isVerified()); // it should be true now
    }

}
