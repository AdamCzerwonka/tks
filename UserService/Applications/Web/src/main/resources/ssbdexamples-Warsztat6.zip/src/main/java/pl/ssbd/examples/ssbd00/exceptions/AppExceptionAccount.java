package pl.ssbd.examples.ssbd00.exceptions;

import jakarta.ws.rs.core.Response;

public class AppExceptionAccount extends AppException {

    public static String ERROR_DELETE_CONFIRMED_ACCOUNT = "ERROR.DELETE_CONFIRMED_ACCOUNT";
    public static String ERROR_ACCOUNT_CONSTRAINT_VIOLATION = "ERROR.ACCOUNT_CONSTRAINT_VIOLATION";

    private AppExceptionAccount(Response.Status status, String key, Throwable cause) {
        super(status, key, cause);
    }

    private AppExceptionAccount(Response.Status status, String key) {
        super(status, key);
    }

    public static AppExceptionAccount createDeleteConfirmedAccount() {
        return new AppExceptionAccount(Response.Status.EXPECTATION_FAILED, ERROR_DELETE_CONFIRMED_ACCOUNT);
    }

    public static AppExceptionAccount createAccountConstraintViolation(Exception e) {
        return new AppExceptionAccount(Response.Status.EXPECTATION_FAILED, ERROR_ACCOUNT_CONSTRAINT_VIOLATION, e);
    }
}
