package pl.ssbd.examples.ssbd00.restclient;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import pl.ssbd.examples.ssbd00.dto.AccountDTO;
import pl.ssbd.examples.ssbd00.dto.CreateClientDTO;

import java.util.List;
import java.util.UUID;

@ApplicationScoped
public class AccountRestClient extends AbstractRestClient<AccountDTO> {

    public AccountRestClient() {
        super(AccountDTO.class);
    }

    @Override
    protected WebTarget getTarget() {
        return getBaseTarget().path("accounts");
    }

    public Response createClient(CreateClientDTO createClientDTO) {
        return getTarget().path("clients").request()
                .post(Entity.entity(createClientDTO,MediaType.APPLICATION_JSON));
    }

    public Response verify(UUID id) {
        return getTarget().path(String.valueOf(id)).path("verify").request()
                .post(Entity.entity(null,MediaType.TEXT_PLAIN_TYPE));
    }

//    PATCH is still not implemented in jaxrs client. SRSLY?!!!One
//    public void update(UUID id, AccountDTO updateAccount) {
//        getTarget().path(String.valueOf(id)).request()
//                .patch(Entity.json(updateAccount);
//    }

    @Override
    public Response findAll() {
        return super.findAll();
    }

    @Override
    public Response find(UUID id) {
        return super.find(id);
    }

    @Override
    public Response remove(UUID id) {
        return super.remove(id);
    }

}
