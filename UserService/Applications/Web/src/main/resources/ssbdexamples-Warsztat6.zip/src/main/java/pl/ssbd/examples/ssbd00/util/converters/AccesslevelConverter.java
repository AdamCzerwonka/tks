package pl.ssbd.examples.ssbd00.util.converters;

import pl.ssbd.examples.ssbd00.dto.*;
import pl.ssbd.examples.ssbd00.model.*;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public class AccesslevelConverter {

    // Ta konwersja jest używana do wysyłania obiektów do warstwy prezentacji
    public static AdminDTO createAdminDTO(Admin admin) {
        return new AdminDTO(admin.getAlarmCode(), admin.getLevel(), admin.getId(), admin.getVersion());
    }

    // Ta konwersja jest używana do utworzenia NOWEGO (i tylko nowego) obiektu encji na podstawie danych z warstwy prezentacji
    // Nie ustawiamy pola poziom - to dzieje się automatycznie po utrwaleniu nowej encji,
    // bo jest to dyskryminator w strategii dziedziczenia JOINED
    public static Admin createNewAdminEntity(AdminDTO adminDTO) {
        return new Admin(adminDTO.getAlarmCode());
    }

    // Ta konwersja jest używana do wysyłania obiektów do warstwy prezentacji
    public static ClientDTO createClientDTO(Client client) {
        return new ClientDTO(client.getNip(), client.getLevel(), client.getId(), client.getVersion());
    }

    // Ta konwersja jest używana do utworzenia NOWEGO (i tylko nowego) obiektu encji na podstawie danych z warstwy prezentacji
    // Nie ustawiamy pola poziom - to dzieje się automatycznie po utrwaleniu nowej encji,
    // bo jest to dyskryminator w strategii dziedziczenia JOINED
    public static Client createNewClientEntity(ClientDTO clientDTO) {
        return new Client(clientDTO.getNip());
    }

    // Ta konwersja jest używana do wysyłania obiektów do warstwy prezentacji
    public static ManagerDTO createManagerDTO(Manager manager) {
        return new ManagerDTO(manager.getPhone(), manager.getLevel(), manager.getId(), manager.getVersion());
    }
    
    // Ta konwersja jest używana do utworzenia NOWEGO (i tylko nowego) obiektu encji na podstawie danych z warstwy prezentacji
    // Nie ustawiamy pola poziom - to dzieje się automatycznie po utrwaleniu nowej encji,
    // bo jest to dyskryminator w strategii dziedziczenia JOINED
    public static Manager createNewManagerEntity(ManagerDTO ManagerDto) {
        return new Manager(ManagerDto.getPhone());
    }
    
    /* Dlaczego nie podoba mi się to rozwiązanie (przeciążenie)? Bo jest zamknięte.
       Czy rozwiązanie otwarte byłoby możliwe? Tak, poprzez polimorfizm. Ale wymagałoby to dołączenia kodu konwertującego
       do klas modelu (encji lub DTO) i przez to stworzenia silnego wiązania (tight coupling) między encjami i DTO.
       Pattern matching switch - zawsze to kapkę lepsze, niż if'y ;)
     */
    // liczymy na to, że mapper do JSON uzyje refleksji i odczyta wszystkie gettery (Jackson to robi)
    public static AccessLevelDTO createAccessLevelDTO(AccessLevel accessLevel) {
        return switch (accessLevel) {
            case Admin a -> createAdminDTO(a);
            case Client c -> createClientDTO(c);
            case Manager m -> createManagerDTO(m);
            default -> throw new IllegalArgumentException("DTO conversion not implemented for: " + accessLevel.getClass());
        };
    }

    // Konwersja listy encji na listę DTO
    // liczymy na to, że mapper do JSON uzyje refleksji i odczyta wszystkie gettery
    public static List<AccessLevelDTO> createAccessLevelDTOList(Collection<AccessLevel> accessLevels) {
        return null == accessLevels ? null : accessLevels.stream()
        .filter(Objects::nonNull)
        .map(AccesslevelConverter::createAccessLevelDTO)
        .collect(Collectors.toList());    
    }

    
}
