package pl.ssbd.examples.ssbd00.tx;

import jakarta.transaction.Synchronization;

public class TransactionSynchronization implements Synchronization {

    public static enum TransactionStatus { // Why isn't it implemented in jakarta.transaction???
        // @see https://javaee.github.io/javaee-spec/javadocs/constant-values.html#javax.transaction.Status.STATUS_ACTIVE
        STATUS_ACTIVE, STATUS_MARKED_ROLLBACK, STATUS_PREPARED, STATUS_COMMITTED, STATUS_ROLLEDBACK,
        STATUS_UNKNOWN, STATUS_NO_TRANSACTION, STATUS_PREPARING, STATUS_COMMITTING, STATUS_ROLLING_BACK
    }
    private String txKey;

    public TransactionSynchronization(String txKey) {
        this.txKey = txKey;
    }

    @Override
    public void beforeCompletion() {} // no interest for that event

    @Override
    public void afterCompletion(int i) {
        System.out.println("Transaction: " + txKey + " completed with status: " + TransactionStatus.values()[i]);
    }
}
