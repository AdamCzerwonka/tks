package pl.ssbd.examples.ssbd00.mok.facade;

import jakarta.annotation.security.DenyAll;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import jakarta.transaction.Transactional;
import pl.ssbd.examples.ssbd00.interceptors.TxTracked;
import pl.ssbd.examples.ssbd00.model.Account;
import pl.ssbd.examples.ssbd00.common.AbstractFacade;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.UUID;


@Transactional(Transactional.TxType.MANDATORY)
@TxTracked
public class AccountFacade extends AbstractFacade<Account> {

    // Metody AbstractFacade zostały oznaczone jako protected, co oznacza, że każda metoda która ma byc uzyta przez AccountManager
    // musi być jawnie zdefiniowana tu jako publiczna.
    // Po co?
    // Niestety kontener honoruje adnotacje (np. @RolesAllowed)
    // jedynie w przypadku, gdy adnotacja i metoda są jawnie umieszczone w jednej klasie. Nie podlega to dziedziczeniu.

    @PersistenceContext(unitName = "ssbd00mokPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public AccountFacade() {
        super(Account.class);
    }

    @Override
    public void create(Account account) {
        super.create(account);
    }

    @Override
    public void edit(Account entity) {
        super.edit(entity);
    }

    @Override
    public void remove(Account entity) {
        super.remove(entity);
    }

    @Override
    public Optional<Account> find(UUID id) {
        return super.find(id);
    }

    @Override
    public Optional<Account> findAndRefresh(UUID id) {
        return super.findAndRefresh(id);
    }

    @Override
    public List<Account> findAll() {
        return super.findAll();
    }

    @DenyAll //ta metoda nie ma jeszcze swojego wykorzystania w AccountManager
    public Account findByLogin(String login) {
        TypedQuery<Account> tq = em.createNamedQuery("Account.findByLogin", Account.class);
        tq.setParameter("login", login);
        return tq.getSingleResult();
    }

    public List<Account> findAllClientAccounts() {
        TypedQuery<Account> tq = em.createNamedQuery("Client.findAllClientAccounts", Account.class);
        return tq.getResultList();
    }
}
