package pl.ssbd.examples.ssbd00.interceptors;

import jakarta.annotation.Resource;
import jakarta.inject.Inject;
import jakarta.interceptor.AroundInvoke;
import jakarta.interceptor.Interceptor;
import jakarta.interceptor.InvocationContext;
import jakarta.security.enterprise.SecurityContext;
import pl.ssbd.examples.ssbd00.tx.TransactionKeyTracker;

import java.util.logging.Level;
import java.util.logging.Logger;

@Interceptor
@TxTracked
public class TxTrackerInterceptor {

    @Inject
    private SecurityContext sctx;
    private static final Logger loger = Logger.getLogger(TxTrackerInterceptor.class.getName());

    @Inject
    private TransactionKeyTracker txtr;
    @AroundInvoke
    public Object traceInvoke(InvocationContext ictx) throws Exception {
        StringBuilder message = new StringBuilder("Method call: ");
        Object result;
        try {
            try {
                message.append(ictx.getMethod().toString());
                message.append("| txKey: ").append(txtr.getTxKey());
                message.append("| user: ").append(null != sctx.getCallerPrincipal() ? sctx.getCallerPrincipal().getName() : "--ANONYMOUS--");
                message.append("| args: ");
                if (null != ictx.getParameters()) {
                    for (Object param : ictx.getParameters()) {
                        message.append(String.valueOf(param)).append(" ");
                    }
                }
            } catch (Exception e) {
                loger.log(Level.SEVERE, "| Unexpected exception within interceptor: ", e);
                throw e;
            }

            result = ictx.proceed();
            
        } catch (Exception e) {
            message.append("| thrown exception: ").append(e.toString());
            loger.log(Level.SEVERE, message.toString(), e);
            throw e;
        }

        message.append("| returned: ").append(String.valueOf(result)).append(" ");

        loger.info(message.toString());

        return result;
    }
}
