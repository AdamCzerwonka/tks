package pl.ssbd.examples.ssbd00.exceptions.mappers;

import jakarta.ejb.AccessLocalException;
import jakarta.ejb.EJBAccessException;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.ext.ExceptionMapper;
import jakarta.ws.rs.ext.Provider;
import pl.ssbd.examples.ssbd00.exceptions.*;

import java.util.logging.Level;
import java.util.logging.Logger;

// Ten mapper ma obsłużyć wszystkie wyjątki, które nie zostały przemapowane na WebApplicationException
// lub jego potomne wyjątki tej aplikacji.
// Obejmuje to wszystkie wyjątki, których miejsce rzucenia było poza zasięgiem interceptorów mapujących wyjątki.
// W szczególności takim wyjatkiem są EJBAccessException i AccessLocalException w warstwie managerów, ponieważ
// aspekt kontroli dostępu jest realizowany przed aspektem interceptorów

@Provider
public class WebEndpointExceptionMapper implements ExceptionMapper<Throwable> {

    private final String UnknownExceptionMessage = "ERROR.UNKNOWN";
    Logger logger = Logger.getLogger(WebEndpointExceptionMapper.class.getName());

    @Override
    public Response toResponse(final Throwable throwable) {
        // A simple trick to be able to use catch() on exception passed as method call argument
        try {
            throw throwable;
        } catch (WebApplicationException wae) {
            return wae.getResponse();
        } catch (EJBAccessException | AccessLocalException ae) { // TODO na pewno bedzie to inny wyjatek
            // Zbuduj odpowiedź tak samo, jak w przypadku odpowiedniego wyjątku aplikacyjnego
            return AppException.createAppExceptionAccessDenied().getResponse();
        } catch (Throwable t) {
            // W przypadku wszystkich pozostałych wyjątków - zapisz do dziennika zdarzeń
            // i zbuduj odpowiedź tak samo, jak w przypadku odpowiedniego wyjątku aplikacyjnego
            logger.log(Level.SEVERE, UnknownExceptionMessage, throwable);
            return AppException.createAppExceptionGenericError(t).getResponse();
        }
    }
}

