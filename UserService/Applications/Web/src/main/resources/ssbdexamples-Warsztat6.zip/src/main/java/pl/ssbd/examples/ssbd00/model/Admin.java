
package pl.ssbd.examples.ssbd00.model;

import java.io.Serializable;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "admin_data")
/* Adnotacja @DiscriminatorValue określa, jaka wartość znajdzie się w kolumnie oznaczonej @DiscriminatorColumn
 * w tabeli reprezentującej nadrzędną klasę encyjną.
 */
@DiscriminatorValue("ADMIN")
@NamedQueries({
    @NamedQuery(name = "DaneManager.findByAlarmCode", query = "SELECT ad FROM Admin ad WHERE ad.alarmCode = :alarmCode")})
@ToString(callSuper = true)
public class Admin extends AccessLevel implements Serializable {
    private static final long serialVersionUID = 1L;

//    Wersja i klucz główny są dziedziczone z klasy bazowej
//    Gettery, settery i toString generowane przez Lombok
    
//    @NotNull
//    @Size(min = 2, max = 16)
    @Column(name = "alarm_code", length = 16, nullable = false, unique = true)
    @Getter @Setter
    private String alarmCode;

    // Konstruktor bezparametrowy musi być dostępny dla JPA
    public Admin() {
    }
    
    // Konstruktor parametrowy będzie potrzebny wyłącznie do konwersji DTO->Encja przy tworzeniu nowych obiektów
    public Admin(String alarmCode) {
        this.alarmCode = alarmCode;
    }



    

}
