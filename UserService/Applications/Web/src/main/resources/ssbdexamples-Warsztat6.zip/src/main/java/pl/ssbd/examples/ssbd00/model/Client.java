
package pl.ssbd.examples.ssbd00.model;

import java.io.Serializable;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@Entity
@Table(name = "client_data")

/* Adnotacja @DiscriminatorValue określa, jaka wartość znajdzie się w kolumnie oznaczonej @DiscriminatorColumn
 * w tabeli reprezentującej nadrzędną klasę encyjną.
 */
@DiscriminatorValue("CLIENT")
@NamedQueries({
    @NamedQuery(name = "Client.findByNip", query = "SELECT c FROM Client c WHERE c.nip = :nip"),
    @NamedQuery(name = "Client.findAllClientAccounts", query = "SELECT c.account FROM Client c"),
})
@ToString(callSuper = true)
public class Client extends AccessLevel implements Serializable {
    private static final long serialVersionUID = 1L;
    

//    @NotNull
//    @Size(min = 1, max = 10)
    @Column(name = "nip", length = 10, nullable = false, unique = true)
    @Getter @Setter
    private String nip;

    /* Przyjeto jednokierunkowe mapowanie związku Invoice --> ClientData; dlaczego?
        Jak znaleźć wszystkie faktury klienta? Zobacz kwerendy w klasie Invoice.
     */

    // Konstruktor bezparametrowy musi być dostępny dla JPA
    public Client() {
    }
    
    // Konstruktor parametrowy będzie potrzebny wyłącznie do konwersji DTO->Encja przy tworzeniu nowych obiektów
    public Client(String nip) {
        this.nip = nip;
    }
    
    

}
