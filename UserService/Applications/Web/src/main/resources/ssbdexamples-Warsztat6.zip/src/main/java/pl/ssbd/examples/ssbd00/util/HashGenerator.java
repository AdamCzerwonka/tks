package pl.ssbd.examples.ssbd00.util;

public interface HashGenerator {
    public String generateHash(String input);
}
