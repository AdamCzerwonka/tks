package pl.ssbd.examples.ssbd00.exceptions;

import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import lombok.Getter;

public class AppException extends WebApplicationException {

    protected final static String ERROR_UNKNOWN = "ERROR.UNKNOWN";
    protected final static String ERROR_GENERAL_PERSISTENCE = "ERROR.GENERAL_PERSISTENCE";
    protected final static String ERROR_ENTITY_NOT_FOUND = "ERROR.ENTITY_NOT_FOUND";
    protected final static String ERROR_OPTIMISTIC_LOCK = "ERROR.OPTIMISTIC_LOCK";
    protected final static String ERROR_ACCESS_DENIED = "ERROR.ACCESS_DENIED";
    protected final static String ERROR_TRANSACTION_ROLLEDBACK = "ERROR.TRANSACTION_ROLLEDBACK";

    @Getter
    private Throwable cause;

    protected AppException(Response.Status status, String key, Throwable cause) {
        super(Response.status(status).entity(key).build());
        this.cause = cause;
    }

    protected AppException(Response.Status status, String key) {
        super(Response.status(status).entity(key).build());
    }

    // Wyjątek ogólny opakowuje nie obsługiwane inaczej typy wyjątków
    public static AppException createAppExceptionGenericError(Throwable cause) {
        return new AppException(Response.Status.INTERNAL_SERVER_ERROR, ERROR_UNKNOWN, cause);
    }

    public static AppException createAppExceptionGenericError(String key, Throwable cause) {
        return new AppException(Response.Status.INTERNAL_SERVER_ERROR, key, cause);
    }

    public static AppException createAppExceptionGenericPersistenceError(Exception cause) {
        return new AppException(Response.Status.INTERNAL_SERVER_ERROR, ERROR_GENERAL_PERSISTENCE, cause);
    }
    
    public static AppException createAppExceptionAccessDenied() {
        return new AppException(Response.Status.FORBIDDEN, ERROR_ACCESS_DENIED);
    }
    
    public static AppException createAppExceptionTransactionRolledBack() {
        return new AppException(Response.Status.INTERNAL_SERVER_ERROR, ERROR_TRANSACTION_ROLLEDBACK);
    }
    

    // Poszczególne wyjątki potomne tworzymy wtedy,gdy mamy w planach ich odrębną obsługę

    public static AppExceptionNoEntity createAppExceptionNoEntity() {
        return new AppExceptionNoEntity();
    }

    public static AppExceptionOptimisticLock createAppExceptionOptimisticLock() { return new AppExceptionOptimisticLock(); }

}
