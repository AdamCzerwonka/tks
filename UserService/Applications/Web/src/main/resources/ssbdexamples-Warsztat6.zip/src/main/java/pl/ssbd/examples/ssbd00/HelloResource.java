package pl.ssbd.examples.ssbd00;

import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import pl.ssbd.examples.ssbd00.model.Account;
import pl.ssbd.examples.ssbd00.model.Client;
import pl.ssbd.examples.ssbd00.mok.facade.AccountFacade;


@Path("/poc")
public class HelloResource {

    @Inject
    private AccountFacade accountFacade;
    @GET
    public void tryit() {
        String suffix = String.valueOf(System.currentTimeMillis()%1000);
        Account account = new Account("login"+suffix,"hashme"+suffix,"name"+suffix,"surname"+suffix,"email"+suffix);
        Client client = new Client("1112220"+suffix);
        account.addAccessLevel(client);
        client.setAccount(account);

        accountFacade.create(account); // Kaskada PERSIST powinna spowodowac uwtorzenie poziomu dostępu klienta

    }
}