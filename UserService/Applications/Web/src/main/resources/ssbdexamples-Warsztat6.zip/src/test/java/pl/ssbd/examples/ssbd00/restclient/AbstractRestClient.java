package pl.ssbd.examples.ssbd00.restclient;

import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.ClientBuilder;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import pl.ssbd.examples.ssbd00.dto.AbstractDTO;

import java.util.List;
import java.util.UUID;

public abstract class AbstractRestClient<T extends AbstractDTO> {

    private Class<T> entityClass;

    public AbstractRestClient(Class<T> entityClass) {
        this.entityClass = entityClass;
    }

    private final Client restClient = ClientBuilder.newBuilder().build();

    private final WebTarget baseTarget = restClient.target("http://localhost:8080/api/");

    protected WebTarget getBaseTarget() {
        return baseTarget;
    }

    protected abstract WebTarget getTarget();

    // These methods are protected, because there's no "standard set" for every entity type
    // Should you need that method for your type, override and expose method in subclass

    protected Response create(T entity) {
        return getTarget().request(MediaType.APPLICATION_JSON)
                .post(Entity.json(entity));
    }

    protected Response findAll() {
        return getTarget().request(MediaType.APPLICATION_JSON)
                .get();
    }

    protected Response find(UUID id) {
        return getTarget().path(String.valueOf(id)).request(MediaType.APPLICATION_JSON)
                .get();
    }

    protected Response remove(UUID id) {
        return getTarget().path(String.valueOf(id)).request()
                .delete();
    }


}
