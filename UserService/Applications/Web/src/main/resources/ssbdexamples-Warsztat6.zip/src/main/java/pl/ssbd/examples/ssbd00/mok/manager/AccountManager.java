package pl.ssbd.examples.ssbd00.mok.manager;

import jakarta.annotation.security.PermitAll;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import pl.ssbd.examples.ssbd00.exceptions.*;
import pl.ssbd.examples.ssbd00.interceptors.TxTracked;
import pl.ssbd.examples.ssbd00.model.*;
import pl.ssbd.examples.ssbd00.mok.facade.AccountFacade;
import pl.ssbd.examples.ssbd00.util.HashGenerator;

import java.util.List;
import java.util.UUID;

@Transactional(Transactional.TxType.REQUIRES_NEW)
@TxTracked
public class AccountManager implements AccountManagerLocal {

    @Inject
    private AccountFacade accountFacade;

    @Inject
    private HashGenerator hashGenerator;

    @Override
    @PermitAll //Ta metoda musi być dostępna publicznie
    public Account createNewClient(Account account, Client client) {
        // Ta metoda tylko wykonuje createNewAccount. Sens jej istnienia zawiera się w ustawieniu kontroli dostępu.
        return createNewAccount(account, client);
    }

    @Override
    // Tworzy konto z jednym poziomem dostępu. Na tym poziomie szczęśliwie możemy już skorzystać z polimorfizmu.
    public Account createNewAccount(Account account, AccessLevel accessLevel) {
        account.setPassword(hashGenerator.generateHash(account.getPassword()));
        // Dwukierunkowy związek == dwukierunkowe mapowanie
        accessLevel.setAccount(account);
        account.addAccessLevel(accessLevel);
        accountFacade.create(account); // Korzystamy z kaskady PERSISTS, nie ma potrzeby wykonywania create() na AccessLevel
        // Zwróć uwagę, jak wiele błędów może się tu pojawić (głównie związanych z naruszeniami ograniczeń)
        // Celowo pozostawiono to bez rozwiązania - to zadanie dla Ciebie
        // Zobacz implementację updateAccount()
        return account;
    }

    @Override
    public List<Account> findAllAccounts() {
        return accountFacade.findAll();
    }

    @Override
    public Account findAccount(UUID id) {
        return accountFacade.find(id).orElseThrow(() -> AppException.createAppExceptionNoEntity());

    }

    @Override
    public Account findAccountWithAccessLevels(UUID id) {
        // Wczytanie wraz z odświeżeniem, tak aby zagwarantowac załadowanie wartości pola poziom dla konta
        // Problem wystepuje tylko wtedy, gdy jest włączony cache L2 i nowo utworzone konto znajduje sie w cache

        // Wczytanie z odświeżeniem powoduje także poprzez kaskadę REFRESH wczytanie kolekcji
        // Takie wczytanie musi sie dokonać dopóki znajdujemy się w kontekście transakcyjnym
        // Pamiętaj o leniwym ładowaniu domyślnym dla kolekcji! To nie jest zależne od L2
        return accountFacade.findAndRefresh(id).orElseThrow(() -> AppException.createAppExceptionNoEntity());    }

    @Override
    public Account markAccountVerified(UUID id) {
        Account accountToBeMarked = findAccount(id);
        accountToBeMarked.setVerified(true);
        // Operacja edit (merge) w zasadzie nie jest potrzebna, ponieważ ta encja jest w stanie zarządzanym.
        // Ale wykonanie edit() prowadzi do wykonania flush() a to jest potrzebne, aby ewentualne wyjątki
        // zostały rzucone we właściwym miejscu.
        accountFacade.edit(accountToBeMarked);
        return accountToBeMarked;
    }

    @Override
    public Account updateAccount(UUID id, long version, Account accountUpdateData) {
        Account accountToBeUpdated = findAccount(id);

        // Ta implementacja de facto wyznacza, które dane konta mogą być zmieniane
        // Nie jest to najbardziej elegancki kod, ale musimy uwzględnić, że w obiekcie przesłanym jako
        // application/merge-patch+json nie wszystkie pola muszą być ustawione!
        if(null != accountUpdateData.getName())
            accountToBeUpdated.setName(accountUpdateData.getName());
        if(null != accountUpdateData.getSurname())
            accountToBeUpdated.setSurname(accountUpdateData.getSurname());
        if(null != accountUpdateData.getEmail())
            accountToBeUpdated.setEmail(accountUpdateData.getEmail());

        // Operacja edit (merge) w zasadzie nie jest potrzebna, ponieważ ta encja jest w stanie zarządzanym.
        // Ale wykonanie edit() prowadzi do wykonania flush() a to jest potrzebne, aby ewentualne wyjątki
        // zostały rzucone we właściwym miejscu.
        accountFacade.edit(accountToBeUpdated);
        return accountToBeUpdated;
    }

    @Override
    public List<Account> findAllClientAccounts() {
        return accountFacade.findAllClientAccounts();
    }

    @Override
    public void removeAccount(UUID id) {
        accountFacade.find(id).ifPresent((account) -> {
            // Usuwanie usuniętego - musisz zdecydować czy traktujesz to jako błąd czy też nie
            // Ja autor jak widać nie traktuję tego jako błąd - jest to operacja idempotentna
            // inaczej użyłbym .orElseThrow()

            // Przykład warunku z logiki biznesowej. Rzucenie wyjątku dzięki // TODO dzięki @Transactional @ApplicationException(rollback=true)
            // powinno spowodować oznaczenie transakcji do odwołania. W ten sposób nie musimy niczego robić, aby ewentualnie już
            // wykonane operacje zostały odwołane.
            if(account.isVerified()) throw AppExceptionAccount.createDeleteConfirmedAccount();
            else accountFacade.remove(account);
            // Korzystamy z kaskady REMOVE w Account, co powinno spowodować kaskadowe usunięcie poziomów dostępu.
            // Jednak jeśli Account albo którykolwiek AccessLevel ma jakies zwiazki z innymi encjami, które nie mają takiej kaskady,
            // to powinno następić naruszenie ograniczenia klucza obcego i odwołanie tej ransakcji.
            // Powinno się to uwzględnić w segmencie obsługi wyjątków
        });
    }

    @Override
    public void aMethodThatIsntControlledByRolesAllowed() throws AppException {
        System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>> U GOT ME! <<<<<<<<<<<<<<<<<<<<<<<<<");
    }

}
