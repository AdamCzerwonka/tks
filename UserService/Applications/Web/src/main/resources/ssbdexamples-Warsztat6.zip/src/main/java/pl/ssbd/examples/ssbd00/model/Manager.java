
package pl.ssbd.examples.ssbd00.model;

import java.io.Serializable;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "manager_data")
/* Adnotacja @DiscriminatorValue określa, jaka wartość znajdzie się w kolumnie oznaczonej @DiscriminatorColumn
 * w tabeli reprezentującej nadrzędną klasę encyjną.
 */
@DiscriminatorValue("MANAGER")
@NamedQueries({
    @NamedQuery(name = "ManagerData.findByPhone", query = "SELECT md FROM Manager md WHERE md.phone = :phone")
})
@ToString(callSuper = true)
public class Manager extends AccessLevel implements Serializable {
    private static final long serialVersionUID = 1L;

//    Wersja i klucz główny są dziedziczone z klasy bazowej
//    Związek z PoziomDostepu został zastąpiony dziedziczeniem
//    Gettery, settery i toString generowane przez Lombok

//    @NotNull
//    @Size(min = 6, max = 20)
    @Column(name = "phone", length = 20, nullable = false, unique = true)
    @Getter @Setter
    private String phone;

    // Konstruktor bezparametrowy musi być dostępny dla JPA
    public Manager() {
    }
    
    // Konstruktor parametrowy będzie potrzebny wyłącznie do konwersji DTO->Encja przy tworzeniu nowych obiektów
    public Manager(String phone) {
        this.phone = phone;
    }

    

}
