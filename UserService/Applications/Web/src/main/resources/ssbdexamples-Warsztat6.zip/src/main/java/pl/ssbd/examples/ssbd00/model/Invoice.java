package pl.ssbd.examples.ssbd00.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@NoArgsConstructor
@Table(name = "invoice")
@ToString(callSuper = true)
@NamedQueries({
        // Przykłady kwerend PQL odwołujących się do cech obiektów (nie krotek!) powiązanych
        @NamedQuery(name = "Invoice.findByClient", query = "SELECT i FROM Invoice i WHERE i.client = :client"),
        @NamedQuery(name = "Invoice.findByClientNip", query = "SELECT i FROM Invoice i WHERE i.client.nip = :nip")
})
public class Invoice extends AbstractEntity{
    public static enum Status {ISSUED, REJECTED, PAID};

    /* Po wdrożeniu zwróć uwagę na to, jak na poziomie struktur bazy danych zbudowane jest ograniczenie klucza obcego.
     */
    @ManyToOne(optional = false,cascade = CascadeType.PERSIST)
    @JoinColumn(name = "client_id", nullable = false, updatable = false)
    private Client client;

    @Getter @Setter
    @Column(nullable = false, updatable = true)
    @Enumerated(EnumType.STRING) // Lub ORDINAL?
    private Status status = Status.ISSUED;

    @Getter
    @Column(precision = 10, scale = 2, nullable = false, updatable = false)
    private BigDecimal amount;

    @Getter
    @Column(nullable = false, updatable = false)
    private LocalDateTime issueDate;

    @PrePersist
    private void setIssueDate() { issueDate = LocalDateTime.now(); }

}
