package pl.ssbd.examples.ssbd00.dto;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

public class ChangePasswordDTO extends AbstractDTO implements Serializable {

    @Getter
    @Setter
    private String oldPassword;

    @Getter
    @Setter
    private String newPassword;

    // Konstruktor bezparametrowy musi być dostępny dla mappera z JSON
    public ChangePasswordDTO() {
    }
    
    // Nie potrzebujemy to konstruktora parametrowego, ponieważ te obiekty sa tylko nośnikami danych między
    // warstwą prezentacji i logiki; nie zachodzi tu konwersja z/do modelu encyjnego

}
