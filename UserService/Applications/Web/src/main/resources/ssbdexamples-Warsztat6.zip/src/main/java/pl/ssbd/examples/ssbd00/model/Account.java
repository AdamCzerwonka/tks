package pl.ssbd.examples.ssbd00.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.ArrayList;
import java.util.Collection;

@Entity
@NoArgsConstructor
@Table(name = "account")
/* Adnotacja deklarująca łączenie tabel, tzn. reprezentowanie przez tę klasę encyjną krotek z innej tabeli.
 * Aby łączenie tabel mogło funkcjonować, między tabelami musi zachodzić relacja 1:1 - równość kluczy głównych.
 */
@SecondaryTable(name="personal_data")
@NamedQueries({
        @NamedQuery(name = "Account.findAll", query = "SELECT a FROM Account a"),
        @NamedQuery(name = "Account.findByLogin", query = "SELECT a FROM Account a WHERE a.login = :login")
})
@ToString(callSuper = true)
public class Account extends AbstractEntity{
//    @NotNull
//    @Size(min = 1, max = 64)
    @Column(name = "login", updatable = false, length = 64, unique=true, nullable = false)
    @Getter
    private String login;

//    @NotNull
//    @Size(min = 64, max = 64)
    @Column(name = "password", length = 64, nullable = false)
    @Getter @Setter
    @ToString.Exclude //Nie chcemy ujawniac tej wartosci w toString()!
    private String password;

    //    @NotNull
    @Column(name = "verified", nullable = false)
    @Getter @Setter
    private boolean verified = false;

//    @NotNull
    @Column(name = "active", nullable = false)
    @Getter @Setter
    private boolean active = true;

    /* Dzięki zastosowaniu adnotacji @SecondaryTable możliwe jest mapowanie w tej klasie danych z innej tabeli.
     * Nazwa "drugiej" tabeli musi być podana jako wartość atrybutu table adnotacji @Column
     */

//    @NotNull
//    @Size(min = 1, max = 32)
    @Column(name = "name", table="personal_data", length = 32, nullable = false)
    @Getter @Setter
    private String name;

//    @NotNull
//    @Size(min = 1, max = 32)
    @Column(name = "surname", table="personal_data", length = 32, nullable = false)
    @Getter @Setter
    private String surname;

    //    @Pattern(regexp="[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?", message="Invalid email")//if the field contains email address consider using this annotation to enforce field validation
//    @Size(max = 128)
    @Column(name = "email", table="personal_data", length = 128, nullable = false)
    @Getter @Setter
    private String email;

    /* Mapowanie dwukierunkowe związku. Przydatne, jeśli po tę kolekcję trzeba często sięgać.
        Ale: wymaga dwukierunkowego zarządzania!
        Kolekcja wymaga zainicjowania jako kolekcja pusta.
     */
    @ToString.Exclude
    @Getter
    @OneToMany(mappedBy = "account", cascade = {CascadeType.PERSIST, CascadeType.REFRESH, CascadeType.REMOVE})
    private Collection<AccessLevel> accessLevels = new ArrayList<>();

    // Metody usuwającej nie ma, poniewaz raz przypisany poziom może być deaktywowany, a nie usunięty
    public void addAccessLevel(AccessLevel accessLevel) {
        accessLevels.add(accessLevel);
    }

    // Nie używamy Lombok do generowania konstruktora, ponieważ nie chcemy inicjować Id przez konstruktor
    // Ponadto pola verified i active mają wartości domyślne w modelu
    // Konstruktor parametrowy będzie potrzebny wyłącznie do konwersji DTO->Encja przy tworzeniu nowych obiektów
    public Account(String login, String password, String name, String surname, String email) {
        this.login = login;
        this.password = password;
        this.name = name;
        this.surname = surname;
        this.email = email;
    }

}
