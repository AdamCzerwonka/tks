package pl.ssbd.examples.ssbd00.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.util.UUID;

@ToString(callSuper = true)
public class AccessLevelDTO extends AbstractDTO implements Serializable {

    // To pole będzie potrzebne aplikacji JS do stwierdzenia z jakim poziomem dostępu mamy do czynienia
    // Będzie to zmapowane z pola dyskryminatora w strategii dziedziczenia JOINED dla encji
    @Getter @Setter
    private String level;

    // Konstruktor bezparametrowy musi być dostępny dla mappera z JSON
    public AccessLevelDTO() {
    }

    // Konstruktor do konwersji encja -> DTO obejmujący wszystkie pola
    public AccessLevelDTO(String level, UUID id, long version) {
        super(id, version);
        this.level = level;
    }
    
}
