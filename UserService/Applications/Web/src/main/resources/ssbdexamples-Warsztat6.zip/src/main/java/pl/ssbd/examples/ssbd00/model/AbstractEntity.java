package pl.ssbd.examples.ssbd00.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.UUID;

@MappedSuperclass
@ToString
public abstract class AbstractEntity {

    /* Poprzez "zwykłe" (nie mapowane) dziedziczenie (@MappedSuperclass) zapewniamy
    dwa wymagane przez wszystkie klasy encyjne pola klucza głównego i wersji.

    Dla tych pól nie ma konstruktora inicjującego ani setterów. Nigdy nie mamy potrzeby ustawiać tych pól w encji.
    Zaś JPA ustawia te wartości poprzez wstrzykniety bajtkod.
     */
    @Id
    @Column(name = "id", columnDefinition = "UUID", updatable = false) //Zobacz mapowanie bez tej adnotacji!
    @GeneratedValue(strategy = GenerationType.UUID) //Dlaczego @GeneratedValue, gdzie wystarczyłoby = UUID.random()? Aby UUID był generowany tylko wtedy, kiedy to potrzebne, a nie dla każdej powoływanej instancji
    @Getter
    private UUID id;


    /* Adnotacja @Version oznacza pole, które będzie wykorzystane jako tzw. pole wersji.
     * Wartość ta jest automatycznie inkrementowana przy każdej zmianie odpowiedniej krotki w bazie danych.
     * Aplikacja nie powinna uzyskiwać dostępu do tej wartości, jednak w praktyce może wystąpić potrzeba jej kopiowania
     * między modelem encyjnym a DTO.
     */
    @Column(name = "version", nullable = false)
    @Version
    @Getter
    private long version;
    
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (this.getId() != null ? this.getId().hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (object.getClass() != this.getClass()) {
            return false;
        }
        AbstractEntity other = (AbstractEntity) object;
        if ((this.getId() == null && other.getId() != null) || (this.getId() != null && !this.getId().equals(other.getId()))) {
            return false;
        }
        return true;
    }

    
}
