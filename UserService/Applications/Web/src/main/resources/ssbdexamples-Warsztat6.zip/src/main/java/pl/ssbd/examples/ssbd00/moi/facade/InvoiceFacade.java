package pl.ssbd.examples.ssbd00.moi.facade;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import pl.ssbd.examples.ssbd00.common.AbstractFacade;
import pl.ssbd.examples.ssbd00.interceptors.TxTracked;
import pl.ssbd.examples.ssbd00.model.Invoice;

@Transactional(Transactional.TxType.MANDATORY)
@TxTracked
public class InvoiceFacade extends AbstractFacade<Invoice> {

    // Metody AbstractFacade zostały oznaczone jako protected, co oznacza, że każda metoda która ma byc uzyta przez AccountManager
    // musi być jawnie zdefiniowana tu jako publiczna.
    // Po co?
    // Niestety kontener honoruje adnotacje (np. @RolesAllowed, @TransactionAttribute, ale też np. @ApplicationException)
    // jedynie w przypadku, gdy adnotacja i metoda są jawnie umieszczone w jednej klasie. Nie podlega to dziedziczeniu.

    @PersistenceContext(unitName = "ssbd00moiPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public InvoiceFacade() {
        super(Invoice.class);
    }

    @Override
    public void create(Invoice invoice) {
        super.create(invoice);
    }


}
