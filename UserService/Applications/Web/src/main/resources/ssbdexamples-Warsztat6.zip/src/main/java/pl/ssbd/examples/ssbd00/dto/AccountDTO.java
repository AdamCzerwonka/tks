package pl.ssbd.examples.ssbd00.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.UUID;

@ToString(callSuper = true)
public class AccountDTO extends AbstractDTO {

    @Getter
    @Setter
    private String login;

    // Konto DTO nie zawiera hasła. Nie chcemy go wyprowadzac poza warstwe logiki.
    // Do ustawiania hasła służy osobne DTO
    @Getter
    @Setter
    private boolean verified;

    @Getter
    @Setter
    private boolean active;

    // Związek z poziomami dostępu nie jest mapowany w DTO
    // Zawsze 2x się zastanów czy na pewno potrzebujesz przenosić kolekcje do DTO
    // Przeważnie lepszym rozwiązaniem jest udostępnienie w API metody do pobrania tej kolekcji wtedy, kiedy jest to NAPRAWDĘ potrzebne
    @Getter
    @Setter
    private String name;

    @Getter
    @Setter
    private String surname;

    @Getter
    @Setter
    private String email;

    // Konstruktor bezparametrowy musi być dostępny dla mappera z JSON
    public AccountDTO() {
    }

    // Konstruktor do konwersji encja -> DTO obejmujący wszystkie pola
    public AccountDTO(String login, boolean verified, boolean active, String name, String surname, String email, UUID id, long version) {
        super(id, version);
        this.login = login;
        this.verified = verified;
        this.active = active;
        this.name = name;
        this.surname = surname;
        this.email = email;
    }
    
}
