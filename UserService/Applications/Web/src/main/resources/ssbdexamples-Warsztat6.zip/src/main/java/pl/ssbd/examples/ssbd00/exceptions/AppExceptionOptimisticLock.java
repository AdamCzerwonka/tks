package pl.ssbd.examples.ssbd00.exceptions;

import jakarta.ws.rs.core.Response;

public class AppExceptionOptimisticLock extends AppException {

    AppExceptionOptimisticLock() {
        super(Response.Status.CONFLICT, ERROR_OPTIMISTIC_LOCK);
    }

}
