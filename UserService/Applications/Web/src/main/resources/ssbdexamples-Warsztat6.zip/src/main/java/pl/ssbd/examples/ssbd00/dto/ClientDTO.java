package pl.ssbd.examples.ssbd00.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.util.UUID;

@ToString(callSuper = true)
public class ClientDTO extends AccessLevelDTO implements Serializable {

    @Getter
    @Setter
    private String nip;

    // Konstruktor bezparametrowy musi być dostępny dla mappera z JSON
    public ClientDTO() {
    }

    // Konstruktor do konwersji encja -> DTO obejmujący wszystkie pola
    public ClientDTO(String nip, String level, UUID id, long version) {
        super(level, id, version);
        this.nip = nip;
    }
    
}
