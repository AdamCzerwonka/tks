package pl.ssbd.examples.ssbd00.config;

import jakarta.annotation.sql.DataSourceDefinition;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

@DataSourceDefinition( // Ta pula połączeń jest na potrzeby tworzenia struktur przy wdrażaniu aplikacji
        name = "java:app/jdbc/ssbd00admin",
        className = "org.postgresql.ds.PGSimpleDataSource",
        user = "ssbd00admin",
        password = "admin",
        serverName = "127.0.0.1",
        portNumber = 5432,
        databaseName = "ssbd00",
        initialPoolSize = 1,
        minPoolSize = 0,
        maxPoolSize = 1,
        maxIdleTime = 10) //Nie potrzebujemy przetrzymywać połączeń w tej puli

@DataSourceDefinition( // Ta pula połączeń jest na potrzeby uwierzytelniania
        name = "java:app/jdbc/ssbd00auth",
        className = "org.postgresql.ds.PGSimpleDataSource",
        user = "ssbd00auth",
        password = "auth",
        serverName = "127.0.0.1",
        portNumber = 5432,
        databaseName = "ssbd00"
        ) //Nie potrzebujemy przetrzymywać połączeń w tej puli

@DataSourceDefinition( // Ta pula połączeń jest na potrzeby MOK
        name = "java:app/jdbc/ssbd00mok",
        className = "org.postgresql.ds.PGSimpleDataSource",
        user = "ssbd00mok",
        password = "mok",
        serverName = "127.0.0.1",
        portNumber = 5432,
        databaseName = "ssbd00"
        ) //Nie potrzebujemy przetrzymywać połączeń w tej puli

@DataSourceDefinition( // Ta pula połączeń jest na potrzeby MOI
        name = "java:app/jdbc/ssbd00moi",
        className = "org.postgresql.ds.PGSimpleDataSource",
        user = "ssbd00moi",
        password = "moi",
        serverName = "127.0.0.1",
        portNumber = 5432,
        databaseName = "ssbd00"
        ) //Nie potrzebujemy przetrzymywać połączeń w tej puli


public class JDBCConfig {
    @PersistenceContext(unitName = "ssbd00adminPU")
    private EntityManager em;
}
