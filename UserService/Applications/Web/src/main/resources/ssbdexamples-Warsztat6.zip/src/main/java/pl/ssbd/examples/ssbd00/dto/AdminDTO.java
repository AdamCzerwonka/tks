package pl.ssbd.examples.ssbd00.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.util.UUID;

@ToString(callSuper = true)
public class AdminDTO extends AccessLevelDTO implements Serializable {

    @Getter
    @Setter
    private String alarmCode;

    // Konstruktor bezparametrowy musi być dostępny dla mappera z JSON
    public AdminDTO() {
    }

    // Konstruktor do konwersji encja -> DTO obejmujący wszystkie pola
    public AdminDTO(String alarmCode, String level, UUID id, long version) {
        super(level, id, version);
        this.alarmCode = alarmCode;
    }
    
}
