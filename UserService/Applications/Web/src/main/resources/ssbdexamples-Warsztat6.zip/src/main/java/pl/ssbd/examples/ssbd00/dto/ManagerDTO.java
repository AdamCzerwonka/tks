package pl.ssbd.examples.ssbd00.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.util.UUID;

@ToString(callSuper = true)
public class ManagerDTO extends AccessLevelDTO implements Serializable {

    @Getter
    @Setter
    private String phone;

    // Konstruktor bezparametrowy musi być dostępny dla mappera z JSON
    public ManagerDTO() {
    }

    // Konstruktor do konwersji encja -> DTO obejmujący wszystkie pola
    public ManagerDTO(String phone, String level, UUID id, long version) {
        super(level, id, version);
        this.phone = phone;
    }
    
}
