
package pl.ssbd.examples.ssbd00.exceptions;

import jakarta.ws.rs.core.Response;

public class AppExceptionNoEntity extends AppException {

    AppExceptionNoEntity() {
        super(Response.Status.NOT_FOUND, ERROR_ENTITY_NOT_FOUND);
    }

}
